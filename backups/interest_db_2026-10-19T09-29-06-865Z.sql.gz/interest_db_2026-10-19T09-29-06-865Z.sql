
-- Interest Database Schema & Data Backup
-- Generated: 2026-10-19T09:29:07.039Z
-- Invariant: ZERO_LOCATION_POLICY_ENFORCED

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "vector";

-- 1. Users table (Strict zero-location: NO lat, lon, city, country, or IP)
CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) UNIQUE NOT NULL,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    display_name VARCHAR(100),
    bio TEXT,
    avatar_url TEXT,
    website_url TEXT,
    is_verified BOOLEAN DEFAULT FALSE,
    is_private BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Interests table
CREATE TABLE IF NOT EXISTS interests (
    id VARCHAR(100) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    category VARCHAR(100) NOT NULL,
    icon_name VARCHAR(50),
    embedding vector(128),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Reels & Posts table
CREATE TABLE IF NOT EXISTS reels (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    creator_id UUID REFERENCES users(id),
    title VARCHAR(255) NOT NULL,
    caption TEXT,
    hls_master_url TEXT,
    thumbnail_url TEXT,
    duration_seconds NUMERIC(6,2),
    primary_interest_id VARCHAR(100) REFERENCES interests(id),
    interest_tag_ids TEXT[],
    status VARCHAR(50) DEFAULT 'READY',
    view_count BIGINT DEFAULT 0,
    like_count BIGINT DEFAULT 0,
    comment_count BIGINT DEFAULT 0,
    save_count BIGINT DEFAULT 0,
    share_count BIGINT DEFAULT 0,
    is_pinned BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. Communities table
CREATE TABLE IF NOT EXISTS communities (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL,
    topic_id VARCHAR(100) REFERENCES interests(id),
    description TEXT,
    is_private BOOLEAN DEFAULT FALSE,
    member_count INT DEFAULT 1,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. Audit logs table
CREATE TABLE IF NOT EXISTS audit_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    actor_id UUID,
    action VARCHAR(100) NOT NULL,
    resource_type VARCHAR(100) NOT NULL,
    resource_id VARCHAR(100) NOT NULL,
    details JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Baseline Seed Records
INSERT INTO users (id, email, username, password_hash, display_name, is_verified) 
VALUES ('c0000000-0000-0000-0000-000000000001', 'creator@interest.app', 'interest_creator', '$2b$10$abcdefghijklmnopqrstuv', 'Interest Creator', TRUE)
ON CONFLICT (id) DO NOTHING;

INSERT INTO interests (id, name, category) 
VALUES ('topic_ai', 'Artificial Intelligence', 'Technology')
ON CONFLICT (id) DO NOTHING;
